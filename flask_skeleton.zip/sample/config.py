class Config:
    SECRET_KEY = 'bu-gizli-anahtari-degistirin'
