from flask_wtf import FlaskForm

# formları burada oluşturun
