# Veritabanı modellerini burada tanımlayın
