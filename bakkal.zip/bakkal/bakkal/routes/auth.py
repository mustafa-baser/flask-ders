from flask import Blueprint, render_template, request, flash, redirect, url_for

auth_bp = Blueprint('auth', __name__)

from bakkal.models import User, Product, Basket
from bakkal.forms import LoginForm
from bakkal.extensions import login
from flask_login import login_user, logout_user


@login.user_loader
def load_user(id):
    return User.query.get(int(id))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST':
        username = form.username.data
        password = form.password.data
        user_obj = User.query.filter_by(username=username).first()
        if user_obj and user_obj.check_password(password):
            flash("Giriş başarılı")
            login_user(user_obj)
            return redirect(url_for('index.index'))
        else:
            flash("Hatalı giriş")

    return render_template('auth/login_form.html', form=form)

@auth_bp.route('/logout')
def logout():
    logout_user()
    flash("Bol paranız olduğunda yine bekleriz")
    return redirect(url_for('index.index'))
