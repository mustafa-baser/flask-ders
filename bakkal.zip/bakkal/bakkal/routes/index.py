from flask import Blueprint, render_template
from bakkal.models import Product
from flask_login import current_user

index_bp = Blueprint('index', __name__)


@index_bp.route('/')
def index():
    products = Product.query.all()
    
    return render_template('index/index.html', products=products)


@index_bp.route('/sepet')
def sepet():
    basket = current_user.basket.all()
    total = 0
    
    for item in basket:
        total += item.amount * item.product.price
    
    return render_template('index/sepet.html', basket=basket, total=total)
