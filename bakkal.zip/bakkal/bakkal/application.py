from flask import Flask

from bakkal.config import Config
from bakkal.routes.index import index_bp
from bakkal.routes.auth import auth_bp
from bakkal.extensions import db, migrate, login


def create_app():
    app = Flask(__name__)

    # Uygulama yapılandırılıyor
    app.config.from_object(Config)

    # Eklentileri burada etkinleştirin
    # Örnek: eklenti.init_app(app)
    db.init_app(app)
    migrate.init_app(app, db)
    login.init_app(app)
    
    # Blueprint'ler burada kayıtlanıyor
    app.register_blueprint(index_bp, url_prefix='')
    app.register_blueprint(auth_bp, url_prefix='/auth')

    return app
