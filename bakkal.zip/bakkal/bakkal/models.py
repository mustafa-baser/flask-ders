# Veritabanı modellerini burada tanımlayın
from werkzeug.security import generate_password_hash, check_password_hash
from bakkal.extensions import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True)
    firstname =  db.Column(db.String(64))
    lastname =  db.Column(db.String(64))
    email = db.Column(db.String(100))
    password_hash = db.Column(db.String(168))


    basket = db.relationship('Basket', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        db.session.commit()

    def check_password(self, password):
        return check_password_hash(self.password_hash, password) 

    def __repr__(self):
        return f'<user {self.username}:{self.email}'

        
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), index=True)
    price = db.Column(db.Integer)

        
    def __repr__(self):
        return f'<product {self.title}>'



class Basket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    amount = db.Column(db.Integer)
    
    product = db.relationship("Product")
    
    def __repr__(self):
        return f'<product {self.product.title}>'
